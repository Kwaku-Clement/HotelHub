from django.contrib import admin

from .models import Guest

admin.site.register(Guest)
