from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    # Authentication: Login, Register, and Logout
    path('authentication/', include('authentication.urls')),
    # Dashboard
    path('', include('dashboard.urls')),
    # Rooms
    path('rooms/', include('rooms.urls')),
    # Guests
    path('guests/', include('guests.urls')),
    # Reservations
    path('reservations/', include('reservations.urls')),
]
